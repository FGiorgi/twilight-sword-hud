/* Twilight Sword HUD — roll from the sheet without opening it.
 * Players: their own Champion (or the owned token they select). GM: the selected token.
 * Every roll posts the same chat card as the sheet (see the Twilight Sword Automation card contract),
 * so the companion module's buttons, animations and bonuses keep working. */

const MOD = "twilight-sword-hud";
const TSA = "twilight-sword-automation";

/* ------------------------------------------------------------------ helpers */
const api = () => game.modules.get(TSA)?.api ?? null;
const num = v => Number(v) || 0;
const props = doc => doc?.system?.props ?? {};
const esc = s => foundry.utils.escapeHTML(String(s ?? ""));
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
const isIT = () => String(game.i18n?.lang ?? "en").startsWith("it");
const truthy = v => v === true || v === "true" || v === 1 || v === "1";

const IT = {
  "Feats": "Tratti", "Spells": "Incantesimi", "Inventory": "Inventario", "Initiative": "Iniziativa", "Rest": "Riposo",
  "Short Rest": "Riposo Breve", "Cook / Brew": "Cucina/Distilla", "Dodge": "Schiva", "Parry": "Para", "Actions": "Azioni",
  "Special actions": "Azioni speciali", "Random action": "Azione casuale", "Monster feats": "Tratti del Mostro",
  "Expended": "Esaurito", "Passive": "Passivo", "Action": "Azione", "Reaction": "Reazione", "1 Stamina": "1 Stamina",
  "Move the HUD": "Sposta l’HUD", "Collapse the HUD": "Riduci l’HUD", "Expand the HUD": "Espandi l’HUD",
  "Hearts": "Cuori", "Stamina": "Stamina", "Armor": "Armatura", "HOPE": "Speranza", "Threat": "Minaccia",
  "Unarmed": "Disarmato", "Melee": "Mischia", "Ranged": "Distanza", "Shield": "Scudo", "Arcane missile": "Dardo arcano",
  "Durability": "Durabilità", "Broken": "Rotta", "Roll options": "Opzioni del tiro", "Advantage / Disadvantage": "Vantaggio / Svantaggio",
  "Normal": "Normale", "Advantage": "Vantaggio", "Disadvantage": "Svantaggio", "Modifier (−3 to +3)": "Modificatore (da −3 a +3)",
  "Spend 1 Stamina for Advantage": "Spendi 1 Stamina per il Vantaggio", "Roll": "Tira", "Cast": "Lancia", "Cancel": "Annulla",
  "Take a Rest?": "Fare un Riposo?", "Take a Short Rest?": "Fare un Riposo Breve?",
  "Hearts and Stamina go back to their maximum and every spell is recharged.": "Cuori e Stamina tornano al massimo e tutti gli incantesimi si ricaricano.",
  "You roll the Short Rest dice and choose what to recover.": "Tiri i dadi del Riposo Breve e scegli cosa recuperare.",
  "Click: attack · Shift+click: roll options": "Clic: attacca · Maiusc+clic: opzioni del tiro",
  "Right-click: melee attack with the staff": "Clic destro: attacco in mischia con il bastone",
  "Right-click: arcane missile (Knowledge, Far, 1D4)": "Clic destro: dardo arcano (Sapere, Lontano, 1D4)",
  "Click: cast · Shift+click: roll options": "Clic: lancia · Maiusc+clic: opzioni del tiro",
  "Click: use": "Clic: usa", "Click: use · costs 1 Stamina": "Clic: usa · costa 1 Stamina",
  "Click: use the action": "Clic: usa l’azione", "Click: show it in chat": "Clic: mostralo in chat",
  "uses left": "utilizzi rimasti", "No roll to hit": "Nessun tiro per colpire", "To hit": "Per colpire", "Damage": "Danni",
  "can’t be parried": "non si para", "can’t be dodged": "non si schiva", "no parry": "non si para", "no dodge": "non si schiva",
  "Costs 1 Stamina": "Costa 1 Stamina", "Not enough Stamina.": "Stamina insufficiente.",
  "No ammunition: this attack cannot be made.": "Nessuna munizione: questo attacco non può essere fatto.",
  "left: this attack cannot be made. Choose other ammunition in the weapons table.": "rimaste: questo attacco non può essere fatto. Scegli altre munizioni nella tabella delle armi.",
  "Enable the Twilight Sword Automation module.": "Attiva il modulo Twilight Sword Automation.",
  "HUD palette": "Palette dell’HUD", "Colours of the roll HUD on this computer. Light or dark follows the Sheet style setting of Twilight Sword Automation.": "Colori dell’HUD dei tiri su questo computer. Chiaro o scuro segue l’impostazione Stile delle schede di Twilight Sword Automation.",
  "HUD size": "Dimensione dell’HUD", "Scale of the roll HUD on this computer.": "Scala dell’HUD dei tiri su questo computer.",
  "Show the HUD": "Mostra l’HUD", "Show the roll HUD on this computer.": "Mostra l’HUD dei tiri su questo computer.",
  "Lantern & Night": "Lanterna e Notte", "Candlelight": "Lume di candela", "Brass Lantern": "Lanterna d’ottone", "Deep Sea Brass": "Ottone degli abissi",
  "Reset HUD position": "Ripristina la posizione dell’HUD",
};
const L = s => (isIT() && IT[s]) || s;

const ABIL = [
  ["str", "STR", "FOR", "Strength"], ["agl", "AGL", "AGL", "Agility"], ["vit", "VIT", "VIT", "Vitality"], ["per", "PER", "PER", "Perception"],
  ["wil", "WIL", "VOL", "Will"], ["kno", "KNO", "SAP", "Knowledge"], ["cha", "CHA", "CAR", "Charisma"], ["ste", "STE", "FUR", "Stealth"],
];
const ABIL_NAME = Object.fromEntries(ABIL.map(a => [a[0], a[3]]));
const abbr = k => { const a = ABIL.find(x => x[0] === k); return a ? (isIT() ? a[2] : a[1]) : String(k ?? "").toUpperCase(); };

/** Name of the CSB template an actor uses (works for unlinked tokens too). */
function templateName(doc) {
  const id = doc?.system?.template ?? doc?._source?.system?.template;
  if (!id) return "";
  return game.actors?.get?.(id)?.name ?? game.items?.get?.(id)?.name ?? "";
}
function actorKind(actor) {
  const n = templateName(actor).toLowerCase(), p = props(actor);
  if (n.includes("monster") || "threat" in p) return "monster";
  if (n.includes("champion") || "hope" in p) return "champion";
  if (n.includes("npc") || "disposition" in p) return "npc";
  if (n.includes("party")) return "party";
  return "other";
}
const isWeapon = i => "wtype" in props(i);
const isSpell = i => "sability" in props(i);
const isFeat = i => "activation" in props(i) && "source" in props(i);
const isGear = i => "gcat" in props(i);
const sorted = items => [...items].sort((a, b) => (num(a.sort) - num(b.sort)) || String(a.name).localeCompare(String(b.name)));
const hasStatus = (actor, id) => !!(actor?.statuses?.has?.(id) || actor?.effects?.some?.(e => !e.disabled && e.statuses?.has?.(id)));
const isKO = actor => truthy(props(actor).st_ko) || hasStatus(actor, "ko");
const hasFavor = actor => num(props(actor).fx_favor) > 0 || hasStatus(actor, "favor");

/* ------------------------------------------------------------------ settings */
const PALETTES = { lanternNight: "Lantern & Night", candlelight: "Candlelight", brassLantern: "Brass Lantern", deepSea: "Deep Sea Brass" };
function registerSettings() {
  game.settings.register(MOD, "enabled", { name: L("Show the HUD"), hint: L("Show the roll HUD on this computer."), scope: "client", config: true, type: Boolean, default: true, onChange: () => HUD.refresh() });
  game.settings.register(MOD, "palette", {
    name: L("HUD palette"), hint: L("Colours of the roll HUD on this computer. Light or dark follows the Sheet style setting of Twilight Sword Automation."),
    scope: "client", config: true, type: String, default: "lanternNight",
    choices: Object.fromEntries(Object.entries(PALETTES).map(([k, v]) => [k, L(v)])), onChange: () => HUD.refresh(),
  });
  game.settings.register(MOD, "scale", { name: L("HUD size"), hint: L("Scale of the roll HUD on this computer."), scope: "client", config: true, type: Number, default: 1, range: { min: 0.6, max: 1.6, step: 0.05 }, onChange: () => HUD.refresh() });
  game.settings.register(MOD, "position", { scope: "client", config: false, type: Object, default: {} });
  game.settings.register(MOD, "collapsed", { scope: "client", config: false, type: Object, default: {} });
}
const setting = (k, d) => { try { return game.settings.get(MOD, k) ?? d; } catch (e) { return d; } };

function isDark() {
  let mode = "light";
  try { mode = game.settings.get(TSA, "sheetTheme") ?? "light"; } catch (e) { /* companion not ready */ }
  if (mode === "dark") return true;
  if (mode === "auto") return !!document.body?.classList?.contains("theme-dark");
  return false;
}
const themeClasses = () => `tsh-pal-${PALETTES[setting("palette", "lanternNight")] ? setting("palette", "lanternNight") : "lanternNight"} ${isDark() ? "tsh-dark" : "tsh-light"}`;

/* ------------------------------------------------------------------ chat helpers (card contract) */
const RES = {
  ko: '<span class="ts-fail" style="color:#b3261e">FAILURE (K.O.)</span>',
  crit: '<span class="ts-crit" style="color:#b8860b">CRITICAL SUCCESS</span>',
  fumble: '<span class="ts-fumble" style="color:#b3261e">CRITICAL FAILURE</span>',
  ok: '<span class="ts-ok" style="color:#2e7d32">SUCCESS</span>',
  fail: '<span class="ts-fail" style="color:#b3261e">FAILURE</span>',
};
const resultHTML = c => `<p class="ts-result"><b>${c.ko ? RES.ko : c.r === 1 ? RES.crit : c.r === 12 ? RES.fumble : c.ok ? RES.ok : RES.fail}</b></p>`;
const rollLine = c => `<p class="ts-roll-line">Rolled <b>${c.r}</b> vs <b>${c.tn}</b> ${c.net > 0 ? "<i>(Advantage)</i>" : c.net < 0 ? "<i>(Disadvantage)</i>" : ""}</p>`;
const note = t => `<p class="ts-note ts-bonus">${t}</p>`;

function speakerFor(ctx) {
  const token = ctx.token ?? ctx.actor?.getActiveTokens?.()[0]?.document ?? null;
  return ChatMessage.getSpeaker({ actor: ctx.actor, token });
}
async function post(ctx, html, rolls = []) {
  return ChatMessage.create({ speaker: speakerFor(ctx), content: html, rolls: rolls.filter(Boolean) });
}
async function safeRoll(formula) {
  const f = String(formula ?? "0").trim() || "0";
  try { return await new Roll(f).evaluate(); } catch (e) { console.warn(`${MOD} | bad formula "${f}"`, e); return await new Roll("0").evaluate(); }
}
const isDice = f => /d\d/i.test(String(f ?? ""));

/** The d12 core every Champion/NPC roll shares (sheet variables ts_a, ts_d, ts_net, ts_t, ts_r, ts_ok). */
async function core(actor, { edge = "none", mod = 0, stam = false, advExtra = 0, dis = 0, base = 0, tnExtra = 0 }) {
  const favor = hasFavor(actor) ? 1 : 0;
  const a = (edge === "adv" ? 1 : 0) + (stam ? 1 : 0) + favor + advExtra;
  const d = (edge === "dis" ? 1 : 0) + dis;
  const net = a - d;
  const tn = num(base) + clamp(num(mod) + tnExtra, -3, 3);
  const roll = await new Roll(net > 0 ? "2d12kl" : net < 0 ? "2d12kh" : "1d12").evaluate();
  const r = roll.total, ko = isKO(actor);
  const ok = !ko && (r === 1 || (r <= tn && r !== 12));
  return { roll, r, tn, net, ok, ko, favor };
}

/** Roll options (Shift+click), as the sheet's TS_Roll dialog. Returns {edge, mod, stam} or null. */
async function askOptions(title, okLabel = "Roll") {
  const r = await foundry.applications.api.DialogV2.wait({
    window: { title: `${title}: ${L("Roll options").toLowerCase()}` },
    content: `<div class="ts-js-dialog"><div class="form-group"><label>${L("Advantage / Disadvantage")}</label><select name="edge"><option value="none">${L("Normal")}</option><option value="adv">${L("Advantage")}</option><option value="dis">${L("Disadvantage")}</option></select></div>`
      + `<div class="form-group"><label>${L("Modifier (−3 to +3)")}</label><input type="number" name="mod" value="0" min="-3" max="3"></div>`
      + `<div class="form-group"><label><input type="checkbox" name="stam"> ${L("Spend 1 Stamina for Advantage")}</label></div></div>`,
    buttons: [{ action: "ok", label: L(okLabel), default: true, callback: (e, b) => ({ edge: b.form.elements.edge.value, mod: clamp(num(b.form.elements.mod.value), -3, 3), stam: b.form.elements.stam.checked }) },
      { action: "cancel", label: L("Cancel") }],
    rejectClose: false,
  });
  return r && typeof r === "object" ? r : null;
}
/** Spend Stamina through the companion module (it relays to the GM when needed). */
async function pay(actor, amount, what) {
  const a = api();
  if (a?.payStamina) return a.payStamina(actor, amount, what);
  const st = num(props(actor).stamina);
  if (st < amount) { ui.notifications.warn(`${actor.name}: ${L("Not enough Stamina.")}`); return false; }
  await actor.update({ "system.props.stamina": st - amount });
  return true;
}
/** Shift+click options, and the Stamina they spend. null = cancelled. */
async function getOptions(ctx, ev, title, okLabel) {
  let o = { edge: "none", mod: 0, stam: false };
  if (ev?.shiftKey) { o = await askOptions(title, okLabel); if (!o) return null; }
  if (o.stam && !(await pay(ctx.actor, 1, title))) return null;
  return o;
}
const stamNote = (ctx, o) => o.stam ? `<p class="ts-note">Spent 1 Stamina (${num(props(ctx.actor).stamina)} left).</p>` : "";

/* ------------------------------------------------------------------ Champion / NPC rolls */
async function rollAbility(ctx, abil, ev) {
  const { actor } = ctx, p = props(actor), name = ABIL_NAME[abil];
  const o = await getOptions(ctx, ev, name); if (!o) return;
  const invisible = abil === "ste" && (num(p.fx_invisible) > 0 || hasStatus(actor, "invisible")) ? 1 : 0;
  const c = await core(actor, { ...o, advExtra: invisible, dis: num(p[`dis_${abil}`]), base: p[abil] });
  const html = `<div class="ts-card"><h3 class="ts-card-title">${name}</h3>${rollLine(c)}${c.favor ? note("Advantage: Favor") : ""}${invisible ? note("Advantage: Invisible") : ""}`
    + `${resultHTML(c)}${stamNote(ctx, o)}<span class="tsa-data" hidden data-kind="check" data-abil="${abil}" data-roll="${c.r}" data-tn="${c.tn}" data-hit="${c.ok}" data-dmg="0"></span></div>`;
  return post(ctx, html, [c.roll]);
}
async function rollReaction(ctx, which, ev) {
  const { actor } = ctx, p = props(actor);
  const dodge = which === "dodge", title = dodge ? "Dodge (Agility)" : "Parry (Strength)";
  const o = await getOptions(ctx, ev, title); if (!o) return;
  const c = await core(actor, dodge
    ? { ...o, dis: num(p.dis_agl) + (truthy(p.st_blind) ? 1 : 0), base: p.agl, tnExtra: String(p.kin).toLowerCase() === "kedi" ? 1 : 0 }
    : { ...o, dis: num(p.dis_str) + (truthy(p.st_prone) ? 1 : 0), base: p.str, tnExtra: num(p.has_defensive) });
  const html = `<div class="ts-card"><h3 class="ts-card-title">${title}</h3>${rollLine(c)}${c.favor ? note("Advantage: Favor") : ""}${resultHTML(c)}${stamNote(ctx, o)}`
    + `<span class="tsa-data" hidden data-kind="check" data-abil="${dodge ? "agl" : "str"}" data-roll="${c.r}" data-tn="${c.tn}" data-hit="${c.ok}" data-dmg="0"></span></div>`;
  return post(ctx, html, [c.roll]);
}
async function rollUnarmed(ctx, ev) {
  const { actor } = ctx, p = props(actor);
  const o = await getOptions(ctx, ev, "Unarmed attack"); if (!o) return;
  const c = await core(actor, { ...o, dis: num(p.dis_str) + (truthy(p.st_blind) ? 1 : 0) + (truthy(p.st_prone) ? 1 : 0), base: p.str });
  const d = await safeRoll(num(p.str) >= 8 ? "1d4" : "1d2");
  const total = d.total * (c.r === 1 ? 2 : 1);
  const html = `<div class="ts-card"><h3 class="ts-card-title">Unarmed attack</h3>${rollLine(c)}${c.favor ? note("Advantage: Favor") : ""}${resultHTML(c)}`
    + `<span class="tsa-data" hidden data-kind="attack" data-roll="${c.r}" data-tn="${c.tn}" data-hit="${c.ok}" data-dmg="${total}"></span>`
    + `${c.ok ? `<p class="ts-dmg">Damage: <b>${total}</b>${c.r === 1 ? " (critical hit, doubled)" : ""}</p>` : ""}${stamNote(ctx, o)}</div>`;
  return post(ctx, html, [c.roll, c.ok ? d : null]);
}

/** The weapon's arcane options: a staff (arcane) shoots missiles and can strike in melee; an ARCANE weapon can also shoot a missile. */
function weaponModes(item) {
  const q = props(item);
  const staff = truthy(q.arcane);
  const trait = /ARCANE|ARCANA/i.test(String(q.wfeats ?? ""));
  return { staff, alt: staff ? "melee" : trait ? "missile" : null };
}
const isBroken = q => q.durability !== "" && q.durability !== null && q.durability !== undefined && Number(q.durability) === 0;

/** Ammunition, as the sheet: spends one, or picks the first usable ammunition. Returns {ok, html}. */
async function useAmmo(item) {
  const q = props(item);
  if (!truthy(q.uses_ammo)) return { ok: true, html: "" };
  const actor = item.parent;
  let a = actor?.items?.get?.(q.ammo_id);
  if (a && !(num(props(a).qty) > 0)) { ui.notifications.warn(`${a.name}: 0 ${L("left: this attack cannot be made. Choose other ammunition in the weapons table.")}`); return { ok: false }; }
  if (!a) {
    const all = actor?.items?.filter?.(i => props(i).gcat === "Ammunition" && num(props(i).qty) > 0) ?? [];
    a = all.find(i => !props(i).gdice || props(i).gdice === "0") ?? all[0];
    if (a) await item.update({ "system.props.ammo_id": a.id, "system.props.ammo_name": a.name, "system.props.ammo_dmg": String(props(a).gdice || "0") });
  }
  if (!a) { ui.notifications.warn(L("No ammunition: this attack cannot be made.")); return { ok: false }; }
  const left = num(props(a).qty) - 1;
  await a.update({ "system.props.qty": left });
  return { ok: true, html: `<p class="ts-note">${esc(a.name)} used: ${left} left.</p>` };
}

/** mode: "main" (the weapon's own attack: a missile for staves), "missile" or "melee". */
async function rollWeapon(ctx, item, mode, ev) {
  const { actor } = ctx, p = props(actor), q = props(item);
  const { staff } = weaponModes(item);
  const missile = mode === "missile" || (mode === "main" && staff);
  const suffix = missile ? "arcane missile" : mode === "melee" ? "melee attack" : "attack";
  const o = await getOptions(ctx, ev, `${item.name} — ${suffix}`); if (!o) return;
  const ammo = await useAmmo(item); if (!ammo.ok) return;
  const ranged = String(q.wtype || "M") === "R";
  const abil = missile ? "kno" : (["str", "agl", "per", "kno"].includes(q.ability) ? q.ability : (q.ability ? null : "str"));
  const aim = num(p.fx_aim) > 0 && (missile || ranged) ? 1 : 0;
  const blind = truthy(p.st_blind) ? 1 : 0, prone = truthy(p.st_prone) ? 1 : 0;
  const c = await core(actor, { ...o, advExtra: aim, dis: (abil ? num(p[`dis_${abil}`]) : 0) + blind + prone, base: abil ? p[abil] : p.str, tnExtra: truthy(q.accurate) ? 1 : 0 });
  const blaster = missile && num(p.has_blaster) > 0;
  const dmgF = missile ? (blaster ? "1d6" : "1d4") : (q.damage || "1d4");
  const dRoll = await safeRoll(dmgF);
  const elRoll = truthy(q.elemental) ? await safeRoll("1d4") : null;
  const ammoF = truthy(q.uses_ammo) ? (q.ammo_dmg || "0") : "0";
  const ammoRoll = ammoF && ammoF !== "0" ? await safeRoll(ammoF) : null;
  const total = (dRoll.total + (elRoll?.total ?? 0) + (ammoRoll?.total ?? 0) + num(q.dmg_bonus)) * (c.r === 1 ? 2 : 1);
  const broken = isBroken(q);
  const hit = c.ok && !broken;
  const html = `<div class="ts-card"><h3 class="ts-card-title"><span class=ts-content>${esc(item.name)}</span> — ${suffix}</h3>${ammo.html}${rollLine(c)}`
    + `${c.favor ? note("Advantage: Favor") : ""}${aim ? note("Advantage: Aim") : ""}${blaster ? note("Arcane Blaster: 1D6") : ""}${resultHTML(c)}`
    + `${broken ? '<p class="ts-broken-note">This weapon is broken: it deals no damage.</p>' : ""}`
    + `<span class="tsa-data" hidden data-kind="attack" data-roll="${c.r}" data-tn="${c.tn}" data-hit="${hit}" data-dmg="${total}"></span>`
    + `${hit ? `<p class="ts-dmg">Damage: <b>${total}</b>${c.r === 1 ? " (critical hit, doubled)" : ""}${elRoll ? " incl. elemental" : ""}</p>` : ""}`
    + `${c.r === 12 ? "<p><i>Critical failure: the weapon is damaged. Click its Check button.</i></p>" : ""}${stamNote(ctx, o)}</div>`;
  return post(ctx, html, [c.roll, hit ? dRoll : null, hit ? elRoll : null, hit ? ammoRoll : null]);
}

async function useFeat(ctx, item) {
  const { actor } = ctx, q = props(item);
  const cost = String(q.activation ?? "") === "1 Stamina" ? 1 : 0;
  const st = num(props(actor).stamina);
  const can = cost === 0 || st >= 1;
  const html = `<div class="ts-card"><h3 class="ts-card-title"><span class=ts-content>${esc(item.name)}</span></h3>`
    + `<p><i>${esc(q.source ?? "")} · <span class=ts-code>${esc(q.activation ?? "")}</span></i></p>${q.description ?? ""}`
    + `<span class="tsa-data" hidden data-kind="feat" data-hit="${can}" data-dmg="0" data-fx="${q.fx && q.fx !== "none" ? esc(q.fx) : ""}" data-fxtarget="${esc(q.fx_target ?? "")}" data-fxdur=""></span>`
    + `${cost ? (can ? `<p class="ts-note">Spent 1 Stamina (${st - 1} left).</p>` : '<p class="ts-broken-note">Not enough Stamina to use this feat.</p>') : ""}</div>`;
  if (cost && can) await pay(actor, 1, item.name);
  return post(ctx, html);
}

async function useGear(ctx, item) {
  const { actor } = ctx, q = props(item), a = props(actor);
  const gd = String(q.gdice ?? "").trim();
  const noroll = !gd || gd === "0";
  const g = noroll ? null : await safeRoll(gd);
  const val = g?.total ?? 0;
  const apply = String(q.gapply || "none");
  let res = "";
  if (!noroll) {
    if (apply === "hearts") res = `<p class="ts-dmg">Recover <b>${val}</b> Hearts → ${Math.min(num(a.hearts_max), num(a.hearts) + val)} / ${num(a.hearts_max)}</p>`;
    else if (apply === "stamina") res = `<p class="ts-dmg">Recover <b>${val}</b> Stamina → ${Math.min(num(a.stamina_max), num(a.stamina) + val)} / ${num(a.stamina_max)}</p>`;
    else res = `<p class="ts-dmg">Roll: <b>${val}</b></p>`;
  }
  const consumable = truthy(q.consumable);
  const html = `<div class="ts-card"><h3 class="ts-card-title"><span class=ts-content>${esc(item.name)}</span></h3><p><i>${esc(q.gcat ?? "")}</i></p>${q.description ?? ""}`
    + `<span class="tsa-data" hidden data-kind="use" data-hit="true" data-dmg="0" data-applied="${esc(apply)}"></span>${res}`
    + `${consumable ? (num(q.qty) <= 1 ? '<p class="ts-note">Used up and removed from the sheet.</p>' : `<p class="ts-note">${num(q.qty) - 1} left.</p>`) : ""}</div>`;
  await post(ctx, html, [g]);
  if (apply === "hearts" && val) await actor.update({ "system.props.hearts": Math.min(num(a.hearts_max), num(a.hearts) + val) });
  if (apply === "stamina" && val) await actor.update({ "system.props.stamina": Math.min(num(a.stamina_max), num(a.stamina) + val) });
  if (consumable) { const left = (num(q.qty) || 1) - 1; if (left <= 0) await item.delete(); else await item.update({ "system.props.qty": left }); }
}

/** The sheet's spell script, as is (expended spells, Empowered Spell, Arcane Blaster, armor, magic items, criticals). */
async function castSpell(ctx, it, ev) {
  const actor = ctx.actor;
  const D = foundry.applications.api.DialogV2;
  const p = it.system.props, a = actor.system.props;
  const abil = String(p.sability || "none");
  if (truthy(a.st_ko)) return ui.notifications.warn(actor.name + " is K.O. and cannot cast spells.");
  if (truthy(a.st_silence)) return ui.notifications.warn(actor.name + " is Silenced and cannot cast spells.");
  let edge = "none", mod = 0, stamAdv = false;
  if (ev?.shiftKey && abil !== "none") { const res = await askOptions(it.name, "Cast"); if (!res) return; edge = res.edge; mod = res.mod; stamAdv = res.stam; }
  let spent = 0;
  if (truthy(p.expended)) {
    const res = await D.wait({ window: { title: it.name + " is expended" },
      content: '<div class="ts-js-dialog"><p><b><span class=ts-content>' + esc(it.name) + '</span></b> is expended. Spend 1 Stamina to cast it again?</p><p>Current Stamina: <b>' + num(a.stamina) + '</b></p><div class="form-group"><label><input type="checkbox" name="free"> Cast it without spending Stamina</label></div></div>',
      buttons: [{ action: "yes", label: "Yes, cast it", default: true, callback: (e, b) => ({ free: b.form.elements.free.checked }) }, { action: "no", label: "No" }], rejectClose: false });
    if (!res || typeof res !== "object") return;
    if (!res.free) spent += 1;
  }
  if (stamAdv) spent += 1;
  if (spent > 0) { const st = num(actor.system.props.stamina); if (st < spent) return ui.notifications.warn("Not enough Stamina to cast " + it.name + "."); await actor.update({ "system.props.stamina": st - spent }); }
  const lc = x => String(x ?? "").toLowerCase();
  const kk = i => lc(i?.flags?.[TSA]?.key ?? i?.name);
  const names = actor.items.map(kk);
  const worn = actor.items.find(i => i.system?.props?.atype !== undefined && i.system.props.worn);
  const wornName = kk(worn);
  const equippedNamed = re => actor.items.some(i => re.test(kk(i)) && i.system?.props?.equipped);
  let castBonus = 0; const why = [];
  if (abil === "kno" && /^(mystic robe|veste mistica|tunica mistica)$/.test(wornName)) { castBonus += 1; why.push(worn.name + " +1"); }
  if (abil === "cha" && /^(priest robe|veste sacerdotale|tunica sacerdotale)$/.test(wornName)) { castBonus += 1; why.push(worn.name + " +1"); }
  const blessAdv = p.category === "Blessing" && equippedNamed(/fairy staff|scettro fatato|bastone fatato/); if (blessAdv) why.push("Fairy Staff: Advantage");
  const thunderPlus = equippedNamed(/staff of gora|scettro di gora|bastone di gora/) && /thunder|fulmin/i.test(String(p.effect ?? "")) ? 2 : 0; if (thunderPlus) why.push("Staff of Gora: +2 damage");
  const score = abil === "none" ? 0 : num(a[abil]);
  const dis = abil === "none" ? 0 : num(a["dis_" + abil]);
  const favorAdv = hasStatus(actor, "favor") ? 1 : 0; if (favorAdv && abil !== "none") why.push("Advantage: Favor");
  const net = (edge === "adv" ? 1 : 0) + (stamAdv ? 1 : 0) + (blessAdv ? 1 : 0) + favorAdv - (edge === "dis" ? 1 : 0) - dis;
  const target = score + Math.max(-3, Math.min(3, mod + castBonus));
  const rolls = []; let r = null; let ok = true;
  if (abil !== "none") { const roll = await new Roll(net > 0 ? "2d12kl" : (net < 0 ? "2d12kh" : "1d12")).evaluate(); rolls.push(roll); r = roll.total; ok = r === 1 || (r <= target && r !== 12); }
  const crit = r === 1, fumble = r === 12;
  let dmg = null; let dform = String(p.sdamage ?? "0").trim(); let empower = null;
  const hasDur = !/^(instant|istantane|until time passes|finch)/i.test(String(p.sduration ?? "").trim()) && String(p.sduration ?? "").trim() !== "";
  const empFeat = actor.items.find(i => String(i.flags?.[TSA]?.key ?? i.name).toLowerCase() === "empowered spell");
  const empUsed = num(empFeat?.flags?.[TSA]?.used) >= 1;
  if (ok && names.includes("empowered spell") && !empUsed && num(actor.system?.props?.stamina) >= 1 && ((dform && dform !== "0") || hasDur)) {
    const it2 = isIT(); const btns = [];
    if (dform && dform !== "0") btns.push({ action: "dmg", label: it2 ? "Raddoppia i danni" : "Double damage" });
    if (hasDur) btns.push({ action: "dur", label: it2 ? "Raddoppia la durata" : "Double duration" });
    btns.push({ action: "no", label: "No", default: true });
    const ch = await D.wait({ window: { title: (it2 ? "Incantesimo Potenziato: " : "Empowered Spell: ") + it.name }, content: '<div class="ts-js-dialog"><p>' + (it2 ? "Spendere 1 Stamina per potenziare l’incantesimo?" : "Spend 1 Stamina to empower the spell?") + "</p></div>", buttons: btns, rejectClose: false });
    if (ch === "dmg" || ch === "dur") {
      empower = ch; await actor.update({ "system.props.stamina": num(actor.system.props.stamina) - 1 });
      if (empFeat) await empFeat.setFlag(TSA, "used", 1);
      why.push(ch === "dmg" ? "Empowered Spell: damage doubled (1 Stamina)" : "Empowered Spell: duration doubled (1 Stamina)");
    }
  }
  if (ok && names.includes("arcane blaster") && /d\d/i.test(dform)) { dform = dform.replace(/(\d*)d(\d+)/gi, "$1d$2r1"); why.push("Arcane Blaster: 1s rerolled"); }
  if (ok && dform && dform !== "0") { const dr = await safeRoll(dform); rolls.push(dr); dmg = dr.total + thunderPlus; }
  if (empower === "dmg" && dmg !== null) dmg = dmg * 2;
  const wasExpended = truthy(p.expended);
  let html = '<div class="ts-card"><h3 class="ts-card-title"><span class=ts-content>' + esc(it.name) + "</span></h3>";
  html += "<p><i><span class=ts-code>" + esc(p.category || "") + "</span> · Range: <span class=ts-content>" + esc(p.srange || "") + "</span> · Duration: <span class=ts-content>" + esc(p.sduration || "") + "</span></i></p>";
  if (wasExpended) html += '<p class="ts-note">' + (spent > (stamAdv ? 1 : 0) ? "Spent 1 Stamina to cast an expended spell." : "Cast while expended, without spending Stamina.") + "</p>";
  const at = String(a.armor_type || "clothing");
  const allowed = ["clothing"].concat(names.some(n => /^(battle mage|mago da battaglia)$/.test(n)) ? ["light"] : []).concat(names.some(n => /^(light guardian|guardiano della luce)$/.test(n)) ? ["light", "medium"] : []);
  if (!allowed.includes(at)) html += '<p class="ts-broken-note">Your armor prevents casting (<span class=ts-code>' + esc(at) + "</span>).</p>";
  if (why.length) html += '<p class="ts-note">' + why.map(esc).join(" · ") + "</p>";
  if (ok && p.category === "Blessing" && names.some(n => /^(inner light|luce interiore)$/.test(n))) html += '<p class="ts-note">Inner Light: you or a Near ally recover 2 Hearts.</p>';
  if (abil === "none") html += '<p class="ts-roll-line">No roll needed.</p>';
  else {
    html += '<p class="ts-roll-line">Rolled <b>' + r + "</b> vs <b>" + target + "</b>" + (net > 0 ? " <i>(Advantage)</i>" : (net < 0 ? " <i>(Disadvantage)</i>" : "")) + "</p>";
    html += '<p class="ts-result">' + (crit ? '<span class="ts-crit">CRITICAL SUCCESS</span>' : (fumble ? '<span class="ts-fumble">CRITICAL FAILURE</span>' : (ok ? '<span class="ts-ok">SUCCESS</span>' : '<span class="ts-fail">FAILURE</span>'))) + "</p>";
  }
  html += "<div class=ts-content>" + (ok ? (p.effect || "") : ((fumble && p.scritfail) ? p.scritfail : (p.sfail || ""))) + "</div>";
  if (dmg !== null) html += '<p class="ts-dmg">Roll: <b>' + dmg + "</b></p>";
  html += crit ? '<p class="ts-note">Critical: the spell is not expended' + (wasExpended && spent > (stamAdv ? 1 : 0) ? " and you recover 1 Stamina" : "") + ".</p>" : '<p class="ts-note"><span class=ts-content>' + esc(it.name) + "</span> is now expended.</p>";
  const fxdur = empower === "dur" && /^\d*d?\d+/i.test(String(p.sduration || "")) ? "2*(" + String(p.sduration).match(/^\d*d?\d+/i)[0] + ")" : (p.sduration || "");
  html += '<span class="tsa-data" hidden data-kind="spell" data-roll="' + (r ?? "") + '" data-tn="' + target + '" data-hit="' + ok + '" data-dmg="' + (dmg ?? 0) + '" data-fx="' + (p.fx && p.fx !== "none" ? esc(p.fx) : "") + '" data-fxtarget="' + esc(p.fx_target || "target") + '" data-fxdur="' + esc(fxdur) + '"></span></div>';
  await post(ctx, html, rolls);
  if (crit) { if (wasExpended && spent > (stamAdv ? 1 : 0)) await actor.update({ "system.props.stamina": num(actor.system.props.stamina) + 1 }); }
  else if (!wasExpended) await it.update({ "system.props.expended": true });
}

async function confirm(title, text) {
  return foundry.applications.api.DialogV2.confirm({ window: { title }, content: `<div class="ts-js-dialog"><p>${text}</p></div>`, rejectClose: false });
}
async function rest(ctx) {
  const { actor } = ctx;
  if (!(await confirm(`${actor.name}: ${L("Rest")}`, `${L("Take a Rest?")} ${L("Hearts and Stamina go back to their maximum and every spell is recharged.")}`))) return;
  const a = props(actor);
  await post(ctx, `<div class="ts-card"><h3 class="ts-card-title">Rest</h3><p>Hearts restored to <b>${num(a.hearts_max)}</b>, Stamina to <b>${num(a.stamina_max)}</b>, all spells recharged.</p><p class="ts-note">Remove 1 status effect (K.O. first, if you have it).</p></div>`);
  await actor.update({ "system.props.hearts": num(a.hearts_max), "system.props.stamina": num(a.stamina_max) });
  for (const sp of actor.items.filter(i => isSpell(i) && truthy(props(i).expended))) await sp.update({ "system.props.expended": false });
}
async function shortRest(ctx) {
  const { actor } = ctx;
  if (!(await confirm(`${actor.name}: ${L("Short Rest")}`, `${L("Take a Short Rest?")} ${L("You roll the Short Rest dice and choose what to recover.")}`))) return;
  const r1 = await safeRoll("1d12"), r2 = await safeRoll("2d12");
  return post(ctx, `<div class="ts-card"><h3 class="ts-card-title">Short Rest</h3><p>Choose one:</p><ul><li>Recover <b>${r1.total}</b> Hearts and 2 Stamina</li><li>Recover <b>${r2.total}</b> Hearts</li><li>Recover 4 Stamina</li><li>Remove 1 status effect</li></ul><p>If you are K.O. you must remove it. You can also recharge 1 expended spell.</p></div>`, [r1, r2]);
}
async function initiative(ctx, ev) {
  const a = api();
  if (!a) return ui.notifications.warn(L("Enable the Twilight Sword Automation module."));
  if (ev?.shiftKey) return a.askEdgeAndRoll(ctx.actor);
  return a.rollInitiativeFor(ctx.actor);
}
async function craft(ctx) {
  const a = api();
  if (!a?.openCrafting) return ui.notifications.warn(L("Enable the Twilight Sword Automation module."));
  return a.openCrafting(ctx.actor);
}

/* ------------------------------------------------------------------ Monster rolls */
const liveRows = obj => Object.entries(obj ?? {}).filter(([, r]) => r && !r.$deleted);
function monsterRows(actor, key) {
  const rows = liveRows(props(actor)[key]);
  if (key === "actions") rows.sort((a, b) => num(a[1].a_num) - num(b[1].a_num));
  return rows;
}
/** A Monster action or special action (pre "a_" or "s_"), as the sheet's Use button. */
async function useMonsterAction(ctx, row, pre, extra = { html: "", rolls: [] }) {
  const { actor } = ctx;
  const st = num(props(actor).stamina);
  const cost = truthy(row[pre + "stam"]) ? 1 : 0;
  const can = cost === 0 || st >= 1;
  const hitN = num(row[pre + "hit"]);
  const hr = can && hitN > 0 ? await safeRoll("1d12") : null;
  const dmgF = String(row[pre + "dmg"] ?? "0").trim() || "0";
  const dr = can && dmgF !== "0" ? await safeRoll(dmgF) : null;
  const d = dr?.total ?? 0;
  const hits = can && (hitN <= 0 || (hr?.total ?? 0) <= hitN);
  const kind = String(row[pre + "kind"] ?? "normal");
  const special = pre === "s_";
  let html = `<div class="ts-card"><h3 class="ts-card-title"><span class=ts-content>${esc(row[pre + "name"] ?? "")}</span>${special ? ' <span class="ts-special">special</span>' : ""}</h3>${extra.html}`
    + `<span class="tsa-data" hidden data-kind="monster" data-blocked="${!can}" data-hit="${hits}" data-dmg="${can ? d : 0}" data-color="${esc(kind)}"></span>`;
  if (cost) html += can ? `<p class="ts-note">Spent 1 Stamina (${st - 1} left).</p>` : '<p class="ts-broken-note">Not enough Stamina: this action can’t be used.</p>';
  if (can) html += hitN > 0 ? `<p class="ts-roll-line">To hit: rolled <b>${hr.total}</b> vs <b>${hitN}</b></p>` : '<p class="ts-roll-line">No roll to hit: the target can only dodge or parry.</p>';
  if (can && hitN > 0) html += hits ? '<p class="ts-result"><span class="ts-ok">HIT</span></p>' : '<p class="ts-result"><span class="ts-fail">MISS</span></p>';
  if (hits && d > 0) html += `<p class="ts-dmg">Damage: <b>${d}</b></p>`;
  html += `<p><span class=ts-content>${esc(row[pre + "effect"] ?? "")}</span></p>`;
  html += kind === "red" ? '<p class="ts-tag ts-tag-red">Red: cannot be parried</p>' : kind === "blue" ? '<p class="ts-tag ts-tag-blue">Blue: cannot be dodged</p>' : "";
  html += "</div>";
  if (cost && can) await actor.update({ "system.props.stamina": st - 1 });
  return post(ctx, html, [...(extra.rolls ?? []), hr, hits ? dr : null]);
}
/** Random action: rolls the action die and uses the action it lands on. */
async function randomAction(ctx) {
  const { actor } = ctx, die = String(props(actor).m_die || "6");
  const roll = await safeRoll(`1d${die}`), n = roll.total;
  const row = monsterRows(actor, "actions").map(([, r]) => r).find(r => num(r.a_num) === n);
  const line = `<p class="ts-roll-line">Random action: D${esc(die)} → <b>${n}</b></p>`;
  if (!row) return post(ctx, `<div class="ts-card"><h3 class="ts-card-title">Random action</h3>${line}<p>No action numbered ${n} in the table.</p></div>`, [roll]);
  return useMonsterAction(ctx, row, "a_", { html: line, rolls: [roll] });
}
async function showMonsterFeat(ctx, row) {
  return post(ctx, `<div class="ts-card"><h3 class="ts-card-title"><span class=ts-content>${esc(row.f_name ?? "")}</span></h3><p><span class=ts-content>${esc(row.f_text ?? "")}</span></p></div>`);
}

/* ------------------------------------------------------------------ which character */
function resolveContext() {
  const tok = canvas?.ready ? canvas.tokens?.controlled?.[0] : null;
  if (game.user.isGM) {
    if (!tok?.actor) return null;
    const kind = actorKind(tok.actor);
    if (!["monster", "champion", "npc"].includes(kind)) return null;
    return { actor: tok.actor, token: tok.document, kind };
  }
  const usable = a => a?.isOwner && ["champion", "npc"].includes(actorKind(a));
  if (tok?.actor && usable(tok.actor)) return { actor: tok.actor, token: tok.document, kind: actorKind(tok.actor) };
  const withToken = a => ({ actor: a, token: a.getActiveTokens?.(false, true)?.[0] ?? null, kind: actorKind(a) });
  if (usable(game.user.character)) return withToken(game.user.character);
  const own = game.actors?.filter?.(a => usable(a) && a.ownership?.[game.user.id] === CONST.DOCUMENT_OWNERSHIP_LEVELS.OWNER) ?? [];
  const last = own.find(a => a.id === HUD.lastActorId);
  const pick = last ?? own.find(a => actorKind(a) === "champion") ?? own[0];
  return pick ? withToken(pick) : null;
}

/* ------------------------------------------------------------------ the HUD */
const ICON = {
  grip: "fa-solid fa-grip-vertical", up: "fa-solid fa-chevron-up", down: "fa-solid fa-chevron-down",
  shield: "fa-solid fa-shield-halved", sun: "fa-solid fa-sun", heart: "fa-solid fa-heart", bolt: "fa-solid fa-bolt",
  threat: "fa-solid fa-dragon", fist: "fa-solid fa-hand-fist",
};
const SIZE = { player: { w: 376, h: 226 }, gm: { w: 356, h: 172 }, mini: { w: 250, h: 128 } };

const HUD = {
  el: null, tip: null, ctx: null, open: null, tips: {}, lastActorId: null, renderTimer: null, pendingRender: false,

  init() {
    this.el = document.createElement("div");
    this.el.id = "tsh-hud";
    this.el.className = "tsh-root tsh-hidden";
    document.body.append(this.el);
    this.tip = document.createElement("div");
    this.tip.id = "tsh-tooltip";
    document.body.append(this.tip);
    this.wire();
    new MutationObserver(() => this.applyTheme()).observe(document.body, { attributes: true, attributeFilter: ["class"] });
    window.addEventListener("resize", foundry.utils.debounce(() => this.place(), 100));
    this.refresh();
  },

  mode() { return this.ctx?.kind === "monster" ? "gm" : "player"; },
  collapsed() { return !!setting("collapsed", {})[this.mode()]; },
  scale() { return clamp(num(setting("scale", 1)) || 1, 0.6, 1.6); },
  size() { return this.collapsed() ? SIZE.mini : SIZE[this.mode()]; },

  applyTheme() {
    if (!this.el) return;
    const cls = themeClasses();
    this.el.className = `tsh-root ${cls}${this.el.classList.contains("tsh-hidden") ? " tsh-hidden" : ""}`;
    this.tip.className = `${cls}${this.tip.classList.contains("tsh-show") ? " tsh-show" : ""}`;
  },

  /** Re-render soon (several updates in a row render once). Never while the user is typing in the HUD. */
  refresh() {
    clearTimeout(this.renderTimer);
    this.renderTimer = setTimeout(() => {
      try {
        if (this.el?.contains(document.activeElement) && document.activeElement?.tagName === "INPUT") { this.pendingRender = true; return; }
        this.render();
      } catch (e) { console.error(`${MOD} | render`, e); }
    }, 30);
  },

  render() {
    if (!this.el) return;
    const ctx = setting("enabled", true) ? resolveContext() : null;
    if (ctx?.actor?.id !== this.ctx?.actor?.id || ctx?.token?.id !== this.ctx?.token?.id) this.open = null;
    this.ctx = ctx;
    this.hideTip();
    if (!ctx) { this.el.classList.add("tsh-hidden"); this.el.innerHTML = ""; return; }
    if (!game.user.isGM) this.lastActorId = ctx.actor.id;
    this.tips = {};
    const body = this.collapsed() ? this.htmlMini() : this.mode() === "gm" ? this.htmlGM() : this.htmlPlayer();
    const s = this.scale(), { w, h } = this.size();
    this.el.innerHTML = `<div class="tsh-scale" style="width:${w}px;height:${h}px;transform:scale(${s})"><div class="tsh-stage" style="width:${w}px;height:${h}px">${body}</div></div>`;
    this.el.style.width = `${w * s}px`; this.el.style.height = `${h * s}px`;
    this.el.classList.remove("tsh-hidden");
    this.applyTheme();
    this.place();
    this.fitText();
    this.placeMenu();
  },

  /* ---------- pieces */
  portrait() {
    const { actor, token } = this.ctx;
    const t = token?.texture?.src;
    return esc(t && !/\.(webm|mp4|ogg)$/i.test(t) ? t : (actor.img || "icons/svg/mystery-man.svg"));
  },
  badge(x, y, icon, value, label) {
    return `<div class="tsh-badge" style="left:${x}px;top:${y}px" aria-label="${esc(L(label))} ${esc(value)}"><i class="${icon}"></i><span>${esc(value)}</span></div>`;
  },
  field(x, y, w, which, mini = false) {
    const p = props(this.ctx.actor), hearts = which === "hearts";
    const max = hearts ? p.hearts_max : p.stamina_max;
    const hasMax = max !== undefined && max !== null && max !== "";
    const temp = hearts && num(p.hearts_temp) > 0 ? `<span class="tsh-temp" title="${esc(L("Hearts"))} +${num(p.hearts_temp)}">+${num(p.hearts_temp)}</span>` : "";
    return `<div class="tsh-field" style="left:${x}px;top:${y}px;width:${w}px"><i class="tsh-ficon ${hearts ? `${ICON.heart} tsh-heart` : `${ICON.bolt} tsh-bolt`}" aria-hidden="true"></i>`
      + `<button class="tsh-pm" data-act="step" data-prop="${which}" data-d="-1" aria-label="${esc(L(hearts ? "Hearts" : "Stamina"))} −1">−</button>`
      + `<span class="tsh-val"><input type="text" inputmode="numeric" data-prop="${which}" value="${num(p[which])}" class="${hasMax ? "" : "tsh-center"}" aria-label="${esc(L(hearts ? "Hearts" : "Stamina"))}">${hasMax ? `<span class="tsh-max">/${num(max)}</span>` : ""}${temp}</span>`
      + `<button class="tsh-pm" data-act="step" data-prop="${which}" data-d="1" aria-label="${esc(L(hearts ? "Hearts" : "Stamina"))} +1">+</button></div>`;
  },
  tool(x, y, h, act) {
    const grip = act === "grip";
    return `<button class="tsh-tool${grip ? " tsh-grip" : ""}" data-act="${act}" style="left:${x}px;top:${y}px;height:${h}px" aria-label="${esc(L(grip ? "Move the HUD" : this.collapsed() ? "Expand the HUD" : "Collapse the HUD"))}"><i class="${grip ? ICON.grip : this.collapsed() ? ICON.down : ICON.up}"></i></button>`;
  },
  word(x, y, w, label, act, extra = "") {
    const active = act === "menu" && this.open === extra;
    return `<button class="tsh-btn${active ? " tsh-active" : ""}" data-act="${act}"${extra ? ` data-menu="${extra}"` : ""} style="left:${x}px;top:${y}px;width:${w}px" aria-expanded="${active}">${esc(L(label))}</button>`;
  },
  column(x, centerY, w, entries) {
    const top = centerY - (entries.length * 26 + (entries.length - 1) * 5) / 2;
    return entries.map((e, i) => ({ ...e, y: top + i * 31 })).map(e => this.word(x, e.y, w, e.label, e.act, e.menu)).join("");
  },
  menuTop(centerY, entries, key) {
    const top = centerY - (entries.length * 26 + (entries.length - 1) * 5) / 2;
    return top + Math.max(0, entries.findIndex(e => e.menu === key)) * 31;
  },

  /* ---------- player layout (Champion / NPC) */
  weapons() { return sorted(this.ctx.actor.items.filter(i => isWeapon(i) && truthy(props(i).equipped))); },
  feats() { return sorted(this.ctx.actor.items.filter(isFeat)); },
  spells() { return sorted(this.ctx.actor.items.filter(isSpell)); },
  gear() {
    const keep = new Set(["Item", "Food", "Potion", "Magic item"]);
    return sorted(this.ctx.actor.items.filter(i => isGear(i) && keep.has(String(props(i).gcat || "Item")) && num(props(i).qty) > 0));
  },

  htmlPlayer() {
    const { actor } = this.ctx, p = props(actor);
    const left = [
      ["feats", "Feats", this.feats()], ["spells", "Spells", this.spells()], ["inventory", "Inventory", this.gear()],
    ].filter(([, , list]) => list.length).map(([menu, label]) => ({ label, act: "menu", menu }));
    if (this.open && !left.some(e => e.menu === this.open)) this.open = null;
    const right = [{ label: "Initiative", act: "init" }, { label: "Rest", act: "rest" }, { label: "Short Rest", act: "srest" }, { label: "Cook / Brew", act: "craft" }];
    let html = this.column(0, 96, 86, left) + this.column(290, 96, 86, right);
    html += `<div class="tsh-avatar" style="left:136px;top:48px;width:104px;height:104px"><img src="${this.portrait()}" alt=""></div>`;
    // weapons: 1 left, 2 right, 3 above
    const slots = [[92, 74], [232, 74], [162, 4]];
    const ws = this.weapons().slice(0, 3);
    if (!ws.length) {
      this.tips.unarmed = { title: L("Unarmed"), meta: `${abbr("str")} · ${num(p.str) >= 8 ? "1D4" : "1D2"}`, body: "", hint: L("Click: attack · Shift+click: roll options") };
      html += `<button class="tsh-weapon" data-act="unarmed" data-tip="unarmed" style="left:${slots[0][0]}px;top:${slots[0][1]}px" aria-label="${esc(L("Unarmed"))}"><i class="${ICON.fist}"></i></button>`;
    }
    ws.forEach((w, i) => {
      const q = props(w), m = weaponModes(w), broken = isBroken(q);
      const type = { M: "Melee", R: "Ranged", S: "Shield" }[String(q.wtype || "M")] ?? "Melee";
      const meta = m.staff
        ? `${L("Arcane missile")} · ${abbr("kno")} · ${num(p.has_blaster) > 0 ? "1D6" : "1D4"}`
        : `${L(type)} · ${abbr(q.ability || "str")} · ${String(q.damage || "1d4").toUpperCase()}${truthy(q.elemental) ? " +1D4" : ""}`;
      const dur = q.durability !== undefined && q.durability !== "" && num(q.durability) >= 0 ? ` · ${L("Durability")} ${broken ? L("Broken") : num(q.durability)}` : "";
      const hint = [L("Click: attack · Shift+click: roll options"), m.alt === "melee" ? L("Right-click: melee attack with the staff") : m.alt === "missile" ? L("Right-click: arcane missile (Knowledge, Far, 1D4)") : ""].filter(Boolean).join("<br>");
      this.tips[`w${w.id}`] = { title: w.name, meta: meta + dur, body: q.description ?? "", hint };
      const [x, y] = slots[i];
      html += `<button class="tsh-weapon${broken ? " tsh-broken" : ""}" data-act="weapon" data-id="${w.id}" data-tip="w${w.id}" style="left:${x}px;top:${y}px" aria-label="${esc(w.name)}"><img src="${esc(w.img || "icons/svg/sword.svg")}" alt="">${m.alt ? `<span class="tsh-alt">${m.alt === "melee" ? "⚔" : "✦"}</span>` : ""}</button>`;
    });
    html += this.badge(112, 30, ICON.shield, num(p.armor), "Armor");
    if ("hope" in p) html += this.badge(228, 30, ICON.sun, num(p.hope), "HOPE");
    html += this.word(33, 159, 54, "Dodge", "dodge") + this.field(93, 160, 92, "hearts") + this.field(191, 160, 92, "stamina") + this.word(289, 159, 54, "Parry", "parry");
    html += this.tool(8, 194, 32, "grip");
    html += `<div class="tsh-abils" style="left:38px;top:194px">${ABIL.map(([k]) => {
      const dis = num(p[`dis_${k}`]) > 0, adv = hasFavor(actor) || (k === "ste" && (num(p.fx_invisible) > 0 || hasStatus(actor, "invisible")));
      return `<button class="tsh-abil" data-act="abil" data-abil="${k}" aria-label="${esc(L(ABIL_NAME[k]))} ${num(p[k])}${dis ? `, ${L("Disadvantage")}` : ""}${adv ? `, ${L("Advantage")}` : ""}"><span class="tsh-ab">${abbr(k)}</span><span class="tsh-sc">${num(p[k])}</span>${dis ? '<span class="tsh-pip tsh-dis"></span>' : ""}${adv ? '<span class="tsh-pip tsh-adv"></span>' : ""}</button>`;
    }).join("")}</div>`;
    html += this.tool(344, 194, 32, "collapse");
    if (this.open) html += this.menuPlayer(this.open, this.menuTop(96, left, this.open));
    return html;
  },

  menuPlayer(key, top) {
    const { actor } = this.ctx;
    const a = api();
    const titles = { feats: "Feats", spells: "Spells", inventory: "Inventory" };
    let rows = "";
    if (key === "feats") rows = this.feats().map(f => {
      const q = props(f), act = String(q.activation ?? "");
      const u = a?.usesOf?.(f), left = u ? a.usesLeft(actor, f) : null;
      const meta = [L(act) || act, u ? `${left}/${u.max}` : ""].filter(Boolean).join(" · ");
      this.tips[`i${f.id}`] = { title: f.name, meta: [L(q.source ?? ""), L(act) || act, u ? `${left}/${u.max} ${L("uses left")}` : ""].filter(Boolean).join(" · "), body: q.description ?? "", hint: act === "1 Stamina" ? L("Click: use · costs 1 Stamina") : L("Click: show it in chat") };
      return this.row({ act: "feat", id: f.id, img: f.img, name: f.name, meta, bolt: act === "1 Stamina", muted: u && left <= 0 });
    }).join("");
    if (key === "spells") rows = this.spells().map(s => {
      const q = props(s), exp = truthy(q.expended), ab = q.sability && q.sability !== "none" ? abbr(q.sability) : "";
      const dmg = q.sdamage && q.sdamage !== "0" ? String(q.sdamage).toUpperCase() : "";
      this.tips[`i${s.id}`] = { title: s.name, meta: [L(q.category ?? ""), ab, q.srange, q.sduration, exp ? L("Expended") : ""].filter(Boolean).join(" · "), body: q.effect ?? "", hint: L("Click: cast · Shift+click: roll options") };
      return this.row({ act: "spell", id: s.id, img: s.img, name: s.name, meta: exp ? L("Expended") : [ab, dmg].filter(Boolean).join(" · "), muted: exp });
    }).join("");
    if (key === "inventory") rows = this.gear().map(g => {
      const q = props(g);
      this.tips[`i${g.id}`] = { title: g.name, meta: [L(q.gcat ?? ""), q.gdice && q.gdice !== "0" ? String(q.gdice).toUpperCase() : ""].filter(Boolean).join(" · "), body: q.description ?? "", hint: L("Click: use") };
      return this.row({ act: "gear", id: g.id, img: g.img, name: g.name, meta: `×${num(q.qty)}` });
    }).join("");
    return `<div class="tsh-menu" data-menu-box style="right:${SIZE.player.w + 8}px;top:${top}px;width:236px"><div class="tsh-menu-head">${esc(L(titles[key]))}</div><div class="tsh-menu-list">${rows}</div></div>`;
  },
  row({ act, id, img, name, meta, bolt = false, muted = false, num: n = null, tag = null, key = null, rowId = null }) {
    const tipId = id ? `i${id}` : `m${key}${rowId}`;
    return `<button class="tsh-row${muted ? " tsh-muted" : ""}" data-act="${act}"${id ? ` data-id="${id}"` : ""}${key ? ` data-key="${key}" data-row="${esc(rowId)}"` : ""} data-tip="${esc(tipId)}">`
      + `${n !== null ? `<span class="tsh-num">${esc(n)}</span>` : ""}${img ? `<img src="${esc(img)}" alt="">` : ""}<span class="tsh-name">${esc(name)}</span>`
      + `${bolt ? `<i class="${ICON.bolt} tsh-rbolt" aria-label="${esc(L("Costs 1 Stamina"))}"></i>` : ""}${tag ? `<span class="tsh-tag tsh-${tag}">${esc(L(tag === "red" ? "no parry" : "no dodge"))}</span>` : ""}`
      + `${meta ? `<span class="tsh-meta">${esc(meta)}</span>` : ""}</button>`;
  },

  /* ---------- GM layout (Monster) */
  htmlGM() {
    const { actor } = this.ctx, p = props(actor);
    const left = [["actions", "Actions"], ["specials", "Special actions"], ["mfeats", "Feats"]]
      .filter(([k]) => monsterRows(actor, k).length).map(([menu, label]) => ({ label, act: "menu", menu }));
    if (this.open && !left.some(e => e.menu === this.open)) this.open = null;
    const right = [{ label: "Initiative", act: "init" }, { label: "Random action", act: "random" }];
    let html = this.column(0, 86, 112, left) + this.column(244, 86, 112, right);
    html += `<div class="tsh-avatar" style="left:126px;top:34px;width:104px;height:104px"><img src="${this.portrait()}" alt=""></div>`;
    html += this.badge(104, 16, ICON.threat, num(p.threat), "Threat") + this.badge(216, 16, ICON.shield, num(p.armor), "Armor");
    html += this.tool(64, 145, 26, "grip") + this.field(94, 146, 92, "hearts") + this.field(192, 146, 70, "stamina") + this.tool(268, 145, 26, "collapse");
    if (this.open) html += this.menuGM(this.open, this.menuTop(86, left, this.open));
    return html;
  },
  menuGM(key, top) {
    const { actor } = this.ctx, st = num(props(actor).stamina);
    const titles = { actions: "Actions", specials: "Special actions", mfeats: "Monster feats" };
    let rows;
    if (key === "mfeats") rows = monsterRows(actor, "mfeats").map(([k, r]) => {
      this.tips[`mmfeats${k}`] = { title: r.f_name ?? "", meta: L("Monster feats"), body: esc(r.f_text ?? ""), hint: L("Click: show it in chat") };
      return this.row({ act: "mfeat", key: "mfeats", rowId: k, name: r.f_name ?? "" });
    }).join("");
    else {
      const pre = key === "actions" ? "a_" : "s_";
      rows = monsterRows(actor, key).map(([k, r]) => {
        const hit = num(r[pre + "hit"]), dmg = String(r[pre + "dmg"] ?? "0").trim(), kind = String(r[pre + "kind"] ?? "normal");
        const stam = truthy(r[pre + "stam"]), blocked = stam && st <= 0;
        const meta = `${hit > 0 ? `≤${hit}` : "auto"}${dmg && dmg !== "0" ? ` ${dmg.toUpperCase()}` : ""}`;
        const tmeta = [hit > 0 ? `${L("To hit")} D12 ≤ ${hit}` : L("No roll to hit"), dmg && dmg !== "0" ? `${L("Damage")} ${dmg.toUpperCase()}` : "",
          kind === "red" ? L("can’t be parried") : kind === "blue" ? L("can’t be dodged") : "", stam ? L("Costs 1 Stamina") : ""].filter(Boolean).join(" · ");
        this.tips[`m${key}${k}`] = { title: `${pre === "a_" ? `${r.a_num ?? ""} · ` : ""}${r[pre + "name"] ?? ""}`, meta: tmeta, body: esc(r[pre + "effect"] ?? "") + (blocked ? `<p><i>${esc(L("Not enough Stamina."))}</i></p>` : ""), hint: L("Click: use the action") };
        return this.row({ act: "maction", key, rowId: k, name: r[pre + "name"] ?? "", meta, bolt: stam, muted: blocked, num: pre === "a_" ? (r.a_num ?? "") : null, tag: kind === "red" || kind === "blue" ? kind : null });
      }).join("");
    }
    return `<div class="tsh-menu" data-menu-box style="right:${SIZE.gm.w + 8}px;top:${top}px;width:262px"><div class="tsh-menu-head">${esc(L(titles[key]))}</div><div class="tsh-menu-list">${rows}</div></div>`;
  },

  /* ---------- collapsed (both) */
  htmlMini() {
    const { actor } = this.ctx, p = props(actor), gm = this.mode() === "gm";
    let html = `<div class="tsh-avatar" style="left:89px;top:18px;width:72px;height:72px;border-width:4px"><img src="${this.portrait()}" alt=""></div>`;
    html += gm ? this.badge(62, 4, ICON.threat, num(p.threat), "Threat") + this.badge(156, 4, ICON.shield, num(p.armor), "Armor")
      : this.badge(62, 4, ICON.shield, num(p.armor), "Armor") + ("hope" in p ? this.badge(156, 4, ICON.sun, num(p.hope), "HOPE") : "");
    html += this.tool(0, 101, 26, "grip") + this.field(30, 102, 92, "hearts") + this.field(128, 102, gm ? 70 : 92, "stamina") + this.tool(gm ? 204 : 226, 101, 26, "collapse");
    return html;
  },

  /* ---------- placement */
  defaultPos() {
    const s = this.scale(), { w, h } = this.size();
    return { x: Math.round((window.innerWidth - w * s) / 2), y: Math.round(window.innerHeight - h * s - 120) };
  },
  place(x, y) {
    if (!this.el || this.el.classList.contains("tsh-hidden")) return;
    const s = this.scale(), { w, h } = this.size();
    if (x === undefined) { const saved = setting("position", {})[this.mode()]; ({ x, y } = saved && Number.isFinite(saved.x) ? saved : this.defaultPos()); }
    x = clamp(x, 0, Math.max(0, window.innerWidth - w * s));
    y = clamp(y, 0, Math.max(0, window.innerHeight - h * s));
    this.el.style.left = `${x}px`; this.el.style.top = `${y}px`;
    return { x, y };
  },
  /** The dropdown opens to the left; near the left edge of the screen it opens to the right instead, and never below the screen. */
  placeMenu() {
    const box = this.el?.querySelector("[data-menu-box]"); if (!box) return;
    const s = this.scale(), hud = this.el.getBoundingClientRect(), w = this.size().w;
    if (hud.left - (box.offsetWidth + 8) * s < 4) { box.style.right = ""; box.style.left = `${w + 8}px`; }
    const r = box.getBoundingClientRect(), over = r.bottom - (window.innerHeight - 4);
    if (over > 0) box.style.top = `${Math.max(-hud.top / s + 4, parseFloat(box.style.top) - over / s)}px`;
  },
  /** Long labels (Italian) shrink to fit their button. */
  fitText() {
    for (const b of this.el.querySelectorAll(".tsh-btn")) {
      let fs = 12;
      while (b.scrollWidth > b.clientWidth + 1 && fs > 8.5) { fs -= 0.5; b.style.fontSize = `${fs}px`; }
    }
  },

  /* ---------- tooltip: above the HUD (below it when there is no room) */
  showTip(id) {
    const t = this.tips[id]; if (!t) return this.hideTip();
    this.tip.innerHTML = `<div class="tsh-tt-title">${esc(t.title)}</div>${t.meta ? `<div class="tsh-tt-meta">${esc(t.meta)}</div>` : ""}${t.body ? `<div class="tsh-tt-body">${t.body}</div>` : ""}${t.hint ? `<div class="tsh-tt-hint">${t.hint}</div>` : ""}`;
    this.tip.classList.add("tsh-show");
    const hud = this.el.getBoundingClientRect(), tw = this.tip.offsetWidth, th = this.tip.offsetHeight;
    const left = clamp(hud.left + hud.width / 2 - tw / 2, 4, window.innerWidth - tw - 4);
    const top = hud.top - th - 8 >= 4 ? hud.top - th - 8 : Math.min(hud.bottom + 8, window.innerHeight - th - 4);
    this.tip.style.left = `${left}px`; this.tip.style.top = `${top}px`;
  },
  hideTip() { this.tip?.classList.remove("tsh-show"); },

  /* ---------- events */
  wire() {
    const el = this.el;
    el.addEventListener("mouseover", ev => { const t = ev.target.closest?.("[data-tip]"); if (t && el.contains(t)) this.showTip(t.dataset.tip); });
    el.addEventListener("mouseout", ev => { const t = ev.target.closest?.("[data-tip]"); if (t && !t.contains(ev.relatedTarget)) this.hideTip(); });
    el.addEventListener("contextmenu", ev => {
      const b = ev.target.closest?.("[data-act='weapon']"); if (!b) return;
      ev.preventDefault(); ev.stopPropagation();
      const item = this.ctx?.actor?.items?.get(b.dataset.id); const alt = item ? weaponModes(item).alt : null;
      if (alt) this.run(() => rollWeapon(this.ctx, item, alt, ev));
    });
    el.addEventListener("click", ev => {
      const b = ev.target.closest?.("[data-act]"); if (!b || !el.contains(b)) return;
      ev.preventDefault(); ev.stopPropagation();
      this.act(b, ev);
    });
    el.addEventListener("change", ev => {
      const input = ev.target.closest?.("input[data-prop]"); if (!input) return;
      this.setValue(input.dataset.prop, input.value);
    });
    el.addEventListener("keydown", ev => { if (ev.key === "Enter" && ev.target.matches?.("input[data-prop]")) ev.target.blur(); ev.stopPropagation(); });
    el.addEventListener("focusout", () => { if (this.pendingRender) { this.pendingRender = false; this.refresh(); } });
    // drag with the grip
    el.addEventListener("pointerdown", ev => {
      const g = ev.target.closest?.(".tsh-grip"); if (!g || ev.button !== 0) return;
      ev.preventDefault();
      const r = el.getBoundingClientRect(), dx = ev.clientX - r.left, dy = ev.clientY - r.top;
      el.classList.add("tsh-dragging"); this.hideTip();
      const move = e => this.place(e.clientX - dx, e.clientY - dy);
      const up = async e => {
        window.removeEventListener("pointermove", move); window.removeEventListener("pointerup", up);
        el.classList.remove("tsh-dragging");
        const pos = this.place(e.clientX - dx, e.clientY - dy); if (!pos) return;
        const all = foundry.utils.deepClone(setting("position", {})); all[this.mode()] = pos;
        await game.settings.set(MOD, "position", all);
        this.placeMenu();
      };
      window.addEventListener("pointermove", move); window.addEventListener("pointerup", up);
    });
  },
  /** Run a roll, never letting an error break the HUD. */
  async run(fn) { try { await fn(); } catch (e) { console.error(`${MOD} |`, e); ui.notifications.error(`Twilight Sword HUD: ${e.message}`); } },

  async act(b, ev) {
    const ctx = this.ctx; if (!ctx) return;
    const act = b.dataset.act, actor = ctx.actor;
    if (act === "grip") return;
    if (act === "collapse") {
      const all = foundry.utils.deepClone(setting("collapsed", {})); all[this.mode()] = !all[this.mode()];
      this.open = null; await game.settings.set(MOD, "collapsed", all); return this.render();
    }
    if (act === "menu") { this.open = this.open === b.dataset.menu ? null : b.dataset.menu; return this.render(); }
    if (act === "step") return this.setValue(b.dataset.prop, String(num(props(actor)[b.dataset.prop]) + num(b.dataset.d)), true);
    if (!actor.isOwner) return ui.notifications.warn("Only the owner of this character can make this roll.");
    const item = b.dataset.id ? actor.items.get(b.dataset.id) : null;
    switch (act) {
      case "abil": return this.run(() => rollAbility(ctx, b.dataset.abil, ev));
      case "dodge": case "parry": return this.run(() => rollReaction(ctx, act, ev));
      case "unarmed": return this.run(() => rollUnarmed(ctx, ev));
      case "weapon": return item && this.run(() => rollWeapon(ctx, item, "main", ev));
      case "feat": return item && this.run(() => useFeat(ctx, item));
      case "spell": return item && this.run(() => castSpell(ctx, item, ev));
      case "gear": return item && this.run(() => useGear(ctx, item));
      case "init": return this.run(() => initiative(ctx, ev));
      case "rest": return this.run(() => rest(ctx));
      case "srest": return this.run(() => shortRest(ctx));
      case "craft": return this.run(() => craft(ctx));
      case "random": return this.run(() => randomAction(ctx));
      case "maction": { const r = props(actor)[b.dataset.key]?.[b.dataset.row]; return r && this.run(() => useMonsterAction(ctx, r, b.dataset.key === "actions" ? "a_" : "s_")); }
      case "mfeat": { const r = props(actor).mfeats?.[b.dataset.row]; return r && this.run(() => showMonsterFeat(ctx, r)); }
    }
  },

  /** Hearts / Stamina from the HUD: a number, or +3 / -5 to change it (as on the sheet). The ± buttons stop at the maximum and at 0. */
  async setValue(prop, raw, step = false) {
    const actor = this.ctx?.actor; if (!actor || !["hearts", "stamina"].includes(prop)) return;
    if (!actor.isOwner) return ui.notifications.warn("Only the owner of this character can change it.");
    const p = props(actor), cur = num(p[prop]), txt = String(raw).trim();
    let v = /^[+-]\d+$/.test(txt) && !step ? cur + Number(txt) : Number(txt);
    if (!Number.isFinite(v)) return this.render();
    v = Math.round(v);
    const max = prop === "hearts" ? p.hearts_max : p.stamina_max;
    if (step && max !== undefined && max !== "" && v > num(max) && cur <= num(max)) v = num(max);
    if (step && v < 0 && (prop === "stamina" || this.ctx.kind === "monster")) v = 0;
    if (v === cur) return this.render();
    await actor.update({ [`system.props.${prop}`]: v });
  },
};

/* ------------------------------------------------------------------ hooks */
Hooks.once("init", () => { registerSettings(); });
Hooks.once("ready", () => {
  if (!game.modules.get(TSA)?.active) console.warn(`${MOD} | Twilight Sword Automation is not active: some buttons won't work.`);
  HUD.init();
  game.modules.get(MOD).api = { HUD, refresh: () => HUD.refresh(), resetPosition: async () => { await game.settings.set(MOD, "position", {}); HUD.render(); } };
});
const isMine = doc => { const a = HUD.ctx?.actor; return !!a && (doc === a || doc?.id === a.id || doc?.parent === a || doc?.parent?.id === a.id); };
const guard = fn => (...args) => { try { fn(...args); } catch (e) { console.warn(`${MOD} | hook`, e); } };
Hooks.on("controlToken", guard(() => HUD.refresh()));
Hooks.on("canvasReady", guard(() => HUD.refresh()));
Hooks.on("updateUser", guard(user => { if (user.id === game.user.id) HUD.refresh(); }));
Hooks.on("updateActor", guard(actor => { if (isMine(actor) || !HUD.ctx) HUD.refresh(); }));
Hooks.on("updateToken", guard(token => { if (token.id === HUD.ctx?.token?.id) HUD.refresh(); }));
Hooks.on("deleteToken", guard(token => { if (token.id === HUD.ctx?.token?.id) HUD.refresh(); }));
for (const h of ["createItem", "updateItem", "deleteItem"]) Hooks.on(h, guard(item => { if (isMine(item)) HUD.refresh(); }));
for (const h of ["createActiveEffect", "updateActiveEffect", "deleteActiveEffect"]) Hooks.on(h, guard(eff => { if (isMine(eff) || isMine(eff?.parent)) HUD.refresh(); }));
Hooks.on("createActor", guard(() => { if (!HUD.ctx) HUD.refresh(); }));
Hooks.on("clientSettingChanged", guard(key => { if (String(key).startsWith(`${TSA}.sheetTheme`)) HUD.applyTheme(); }));
