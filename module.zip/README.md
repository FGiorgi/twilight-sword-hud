# Twilight Sword HUD

Roll from your Twilight Sword sheet without opening it. Needs **Twilight Sword Automation** (0.28.7 or later) and the Twilight Sword templates for Custom System Builder.

## Who sees what
- **Players:** the HUD is always on and shows your Champion. If you own more than one character, select the token you want; otherwise it uses your assigned character.
- **GM:** the HUD follows the selected token. Monsters get the GM HUD (actions, special actions, feats, initiative, random action); Champions and NPCs get the player HUD. With nothing selected it hides.

## Using it
- Click to roll. **Shift+click** opens the roll options (Advantage / Disadvantage, modifier, spend 1 Stamina for Advantage) on abilities, Dodge, Parry, weapons and spells, and Advantage / Disadvantage on initiative.
- **Right-click a weapon** for its second attack: melee with an arcane staff (⚔), or the arcane missile of an ARCANE weapon (✦).
- Feats, Spells and Inventory open a list beside the HUD. Hover anything with a description (weapons, feats, spells, items, Monster actions) to read it above the HUD.
- Hearts and Stamina: use − / +, or type a number (or `+3`, `-5`).
- Drag the HUD with the grip (bottom left); collapse it with the arrow (bottom right). Position and collapsed state are saved per user.
- Random action rolls the Monster's action die and uses the action it lands on.

## Settings (per user, in Configure Settings → Twilight Sword HUD)
- **HUD palette:** Lantern & Night (default), Candlelight, Brass Lantern, Deep Sea Brass. Light or dark follows Twilight Sword Automation's *Sheet style*.
- **HUD size** and **Show the HUD**.
- Reset the position from the console: `game.modules.get("twilight-sword-hud").api.resetPosition()`.

## How the rolls work
The sheet's rolls can't be triggered from code, so the HUD rebuilds them from the templates (v4.10) and posts the same chat cards, so the companion module's buttons, animations and bonuses keep working. If the templates' formulas change, the HUD must be updated too.
